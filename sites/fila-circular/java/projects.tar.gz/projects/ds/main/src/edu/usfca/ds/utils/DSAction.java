package edu.usfca.ds.utils;

import edu.usfca.xj.appkit.gview.object.GElement;

public abstract class DSAction {
    public abstract void perform(GElement element, int index);
}
